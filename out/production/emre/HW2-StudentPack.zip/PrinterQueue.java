
public class PrinterQueue implements IMPMCQueue<PrintItem>
{
    // TODO: This is all yours

    public PrinterQueue(int maxElementCount)
    {
        // TODO: Implement

        // You can change this signature but also don't forget to
        // change the instantiation signature on the
        // Printer room
    }
}
