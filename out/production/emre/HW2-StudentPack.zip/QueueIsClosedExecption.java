
public class QueueIsClosedExecption extends RuntimeException
{
    public QueueIsClosedExecption()
    {
        super("Queue is closed!");
    }

}